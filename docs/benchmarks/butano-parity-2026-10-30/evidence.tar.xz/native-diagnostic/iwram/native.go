package main
import rt "github.com/drpaneas/mtile/runtime"
var nativeReady bool
//go:section .iwram
var nativePX [128]rt.Number
//go:section .iwram
var nativePY [128]rt.Number
//go:section .iwram
var nativeVX [128]rt.Number
//go:section .iwram
var nativeVY [128]rt.Number
