package main
import rt "github.com/drpaneas/mtile/runtime"
var nativeReady bool
//go:section .ewram
var nativePX [128]rt.Number
//go:section .ewram
var nativePY [128]rt.Number
//go:section .ewram
var nativeVX [128]rt.Number
//go:section .ewram
var nativeVY [128]rt.Number
