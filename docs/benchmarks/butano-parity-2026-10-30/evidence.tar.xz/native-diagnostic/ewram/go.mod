module mtile-generated

go 1.27.1

require github.com/drpaneas/mtile/runtime v0.0.0

replace github.com/drpaneas/mtile/runtime => /Users/pgeorgia/gocode/src/github.com/drpaneas/mtile/runtime
