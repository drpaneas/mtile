import pathlib,json,os,sys,shutil,statistics,subprocess
sys.path.insert(0,'scripts/butano-bench');import run as suite,verify
base=pathlib.Path('/private/tmp/mtile-butano-parity');project=base/'butano-project'
if not project.exists():shutil.copytree('/private/tmp/mtile-butano-bench/butano-project',project)
suite.ENV=os.environ.copy();suite.ENV.update(DEVKITPRO='/opt/devkitpro',DEVKITARM='/opt/devkitpro/devkitARM');suite.ENV['PATH']='/opt/devkitpro/devkitARM/bin:/opt/devkitpro/tools/bin:'+suite.ENV['PATH']
template=(suite.HERE/'native/butano.cpp').read_text();begin=template.index('  if constexpr(KIND==10) {');end=template.index('  if constexpr(KIND==11) {',begin)
block=template[begin:end];body=block.split('  if constexpr(KIND==10) {\n',1)[1].removesuffix('  }\n')
workloads={w['name']:w for w in suite.workloads()};results={};checks=[]
for name in ['physics_32','physics_64','physics_128','physics_drag_64']:
 w=workloads[name];suite.generate(w,base)
 golden=verify.pixels(w,0);states=verify.checksums(w,660)
 for variant in ['thumb_iwram','arm_iwram']:
  out=base/'butano-tuned'/name/variant;out.mkdir(parents=True,exist_ok=True)
  attr='__attribute__((noinline'+(', target("arm")'if variant=='arm_iwram'else'')+'))'
  helper='static BN_CODE_IWRAM '+attr+' void physics_step() {\n'+body+'}\n\n'
  code=template.replace(block,'  if constexpr(KIND==10) { physics_step(); }\n',1).replace('int main() {',helper+'int main() {',1).replace('#include "bench_assets.h"','#include "bench_assets.h"\n#include "/private/tmp/mtile-butano-20261029/butano/hw/include/bn_hw_common.h"',1)
  (project/'src/main.cpp').write_text(code);suite.write(out/'main.cpp',code)
  print(name,variant,flush=True);suite.run(['make','-j4'],cwd=project,log=out/'build.log')
  for ext in ['gba','elf']:shutil.copyfile(project/('benchmark.'+ext),out/('butano.'+ext))
  summaries=[]
  for rep in range(2):
   capture=out/f'samples-{rep}.json';suite.run([base/'driver','capture',suite.ROOT/'build/player/mtile-player',out/'butano.gba',capture,out/'final.png',60,600,0]);d=json.loads(capture.read_text())
   for s in d['samples']:
    watches={x['Name']:x['Raw']for x in s['watches']}
    assert s['sha256']==golden and watches['tick']==s['tick']*65536 and watches['checksum']==states[s['tick']]*65536,(name,variant,rep,s['tick'])
   summary=suite.summarize(d);summary['mean']=statistics.mean(s['cycles']for s in d['samples']);summaries.append(summary);checks.append(dict(workload=name,variant=variant,repetition=rep,ticks=600,pixelMismatches=0,stateChecksumMismatches=0))
  symbols=subprocess.check_output(['/opt/devkitpro/devkitARM/bin/arm-none-eabi-nm','-n',out/'butano.elf'],text=True)
  address=[line.split()[0]for line in symbols.splitlines()if len(line.split())==3 and line.split()[2].startswith('_ZL12physics_stepv')];assert len(address)==1 and 0x03000000<=int(address[0],16)<0x03008000,address
  result=dict(summary=summaries[0],repeatMedians=[s['median']for s in summaries],romSHA256=suite.sha(out/'butano.gba'),elfSHA256=suite.sha(out/'butano.elf'),helperAddress=address[0],verifiedTicks=1200)
  results[name+'-'+variant]=result;suite.dump(base/'butano-tuned-results.json',results);print(json.dumps(result),flush=True)
suite.dump(base/'butano-tuned-verification.json',dict(checks=checks,totalTicks=sum(c['ticks']for c in checks),passAll=True))
