import pathlib,json,os,sys,shutil,statistics,subprocess
sys.path.insert(0,'scripts/butano-bench');import run as suite,verify
base=pathlib.Path('/private/tmp/mtile-butano-parity');source=base/'physics_128-local_iwram/mode0.gba.main.go';original=source.read_text()
suite.ENV=os.environ.copy();suite.ENV['GOCACHE']='/private/tmp/mtile-butano-bench/go-cache';suite.ENV['GOWORK']='off'
tags='mtile_mode0,mtile_mode0_layers0,mtile_map_compact,mtile_mode0_sheet_immutable,mtile_static_strings_1,mtile_project_font,mtile_preview_log'
module='module mtile-generated\n\ngo 1.27.1\n\nrequire github.com/drpaneas/mtile/runtime v0.0.0\n\nreplace github.com/drpaneas/mtile/runtime => '+str(suite.ROOT/'runtime')+'\n'
body='''func (g *Game) simulate(c *rt.Context) {
 if !nativeReady {
  for i:=0;i<128;i++ {
   nativePX[i]=c.NumberArrayGet(g.px,i+1); nativePY[i]=c.NumberArrayGet(g.py,i+1)
   nativeVX[i]=c.NumberArrayGet(g.vx,i+1); nativeVY[i]=c.NumberArrayGet(g.vy,i+1)
  }
  nativeReady=true
 }
 g.tick+=rt.One
 var checksum uint32
 for i:=0;i<128;i++ {
  x,y,dx,dy:=nativePX[i],nativePY[i],nativeVX[i],nativeVY[i]+4096
  x+=dx; y+=dy
  if x<4*rt.One{x=4*rt.One;dx=dx.Abs()}else if x>235*rt.One{x=235*rt.One;dx=-dx.Abs()}
  if y<4*rt.One{y=4*rt.One;dy=dy.Abs()}else if y>155*rt.One{y=155*rt.One;dy=-dy.Abs()}
  nativePX[i],nativePY[i],nativeVX[i],nativeVY[i]=x,y,dx,dy
  checksum=(checksum+uint32(x>>16)+uint32(y>>16))%16001
 }
 g.checksum=rt.Number(checksum<<16)
}'''
start=original.index('func (g *Game) simulate(');end=original.index('\n}\n',start)+2
w=next(w for w in suite.workloads()if w['name']=='physics_128');golden=verify.pixels(w,0);states=verify.checksums(w,660);results={};checks=[]
for placement in ['ewram','iwram']:
 out=base/('native-'+placement);out.mkdir(exist_ok=True);(out/'go.mod').write_text(module)
 shutil.copyfile(base/'physics_128-local_iwram/mode0.gba.target-gba.json',out/'target-gba.json')
 (out/'native.go').unlink(missing_ok=True)
 (out/'main.go').write_text(original)
 def compile(output):
  suite.run(['tinygo','build','-gc=none','-opt=2','-target='+str(out/'target-gba.json'),'-tags='+tags,'-o',out/output,'.'],cwd=out,log=out/(output+'.log'))
 compile('unmodified.gba');assert (out/'unmodified.gba').read_bytes()==(base/'physics_128-local_iwram/mode0.gba').read_bytes(),'baseline pipeline differs'
 (out/'main.go').write_text(original[:start]+body+original[end:])
 extra='package main\nimport rt "github.com/drpaneas/mtile/runtime"\nvar nativeReady bool\n'
 for a in ['PX','PY','VX','VY']:extra+='//go:section .'+placement+'\nvar native'+a+' [128]rt.Number\n'
 (out/'native.go').write_text(extra);compile('native.gba');compile('native.elf')
 summaries=[]
 for rep in range(2):
  p=out/f'samples-{rep}.json';suite.run([base/'driver','capture',suite.ROOT/'build/player/mtile-player',out/'native.gba',p,out/'final.png',60,600,0]);d=json.loads(p.read_text())
  for s in d['samples']:
   watches={x['Name']:x['Raw']for x in s['watches']}
   assert s['sha256']==golden and watches['tick']==s['tick']*65536 and watches['checksum']==states[s['tick']]*65536,(placement,rep,s['tick'])
  stat=suite.summarize(d);stat['mean']=statistics.mean(s['cycles']for s in d['samples']);summaries.append(stat);checks.append(dict(placement=placement,repetition=rep,ticks=600,pixelMismatches=0,stateChecksumMismatches=0))
 results[placement]=dict(summary=summaries[0],repeatMedians=[s['median']for s in summaries],romSHA256=suite.sha(out/'native.gba'),elfSHA256=suite.sha(out/'native.elf'),mainSHA256=suite.sha(out/'main.go'),nativeSHA256=suite.sha(out/'native.go'),verifiedTicks=1200,note='Hand-edited native Go diagnostic, not output of the Lua compiler; private arrays are not mirrored back to Lua heap objects.')
 print(placement,json.dumps(results[placement]),flush=True);suite.dump(base/'native-results.json',results)
suite.dump(base/'native-verification.json',dict(checks=checks,totalTicks=sum(c['ticks']for c in checks),passAll=True))
