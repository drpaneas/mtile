tick=0
checksum=0
px={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
py={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
vx={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
vy={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}
function _init()
for i=1,64 do
local j=i-1
px[i]=8+(j*13)%220
py[i]=8+(j*17)%136
vx[i]=((j%7)-3)*0.125
vy[i]=((j%5)-2)*0.125
end
end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
for i=1,64 do
local x=px[i]
local y=py[i]
local dx=vx[i]
local dy=vy[i]+0.0625
x=x+dx
y=y+dy
if x<4 then x=4 dx=abs(dx) elseif x>235 then x=235 dx=-abs(dx) end
if y<4 then y=4 dy=abs(dy) elseif y>155 then y=155 dy=-abs(dy) end
px[i]=x py[i]=y vx[i]=dx vy[i]=dy
checksum=(checksum+flr(x)+flr(y))%16001
end
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
end
