tick=0
checksum=0
audio_mean=0
audio_services=0
function _update()
 tick=tick+1
 if (tick-1)%8==0 then
  local phase=flr((tick-1)/8)%4
  gba_note(1,60+phase*2,0,0)
  gba_note(2,48+phase*2,1,0)
  gba_note(3,36+phase*2,2,0)
  gba_note(4,36,3,0)
 end
 audio_mean=stat(91)
 audio_services=stat(92)
end
function _draw() cls(1) end
