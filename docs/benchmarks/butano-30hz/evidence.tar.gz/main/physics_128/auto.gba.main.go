package main

import (
	rt "github.com/drpaneas/mtile/runtime"
	_ "unsafe"
)

//go:section .rodata
var projectFontExtraROM = [...]rt.FontGlyph{
}
//go:section .rodata
var projectFontROM = rt.Font{ASCII:[95][6]uint16{
{0,0,0,0,0,0},
{0,0,190,0,0,0},
{0,14,0,14,0,0},
{40,254,40,254,40,0},
{8,84,254,84,32,0},
{196,42,84,168,70,0},
{108,146,172,64,160,0},
{0,0,14,0,0,0},
{0,56,68,130,0,0},
{0,130,68,56,0,0},
{84,56,16,56,84,0},
{16,16,124,16,16,0},
{0,256,192,64,0,0},
{16,16,16,16,16,0},
{0,128,448,128,0,0},
{192,32,16,8,6,0},
{56,68,130,68,56,0},
{136,132,254,128,128,0},
{196,162,146,146,140,0},
{66,130,146,154,102,0},
{48,40,36,254,32,0},
{94,146,138,138,114,0},
{120,164,146,146,96,0},
{2,194,34,26,6,0},
{108,146,146,146,108,0},
{12,146,146,74,60,0},
{0,136,476,136,0,0},
{0,264,220,72,0,0},
{0,16,40,68,130,0},
{40,40,40,40,40,0},
{0,130,68,40,16,0},
{4,2,178,10,4,0},
{124,130,178,170,28,0},
{248,36,34,36,248,0},
{130,254,146,146,108,0},
{124,130,130,130,68,0},
{130,254,130,130,124,0},
{254,146,146,146,130,0},
{254,18,18,18,2,0},
{124,130,130,162,100,0},
{254,16,16,16,254,0},
{0,130,254,130,0,0},
{64,128,130,126,2,0},
{254,16,40,68,130,0},
{254,128,128,128,128,0},
{254,8,16,8,254,0},
{254,8,16,32,254,0},
{124,130,130,130,124,0},
{254,18,18,18,12,0},
{124,130,194,130,380,0},
{254,18,50,82,140,0},
{76,146,146,146,100,0},
{2,2,254,2,2,0},
{126,128,128,128,126,0},
{14,112,128,112,14,0},
{254,64,48,64,254,0},
{198,40,16,40,198,0},
{6,8,240,8,6,0},
{194,162,146,138,134,0},
{0,254,130,130,0,0},
{6,8,16,32,192,0},
{0,130,130,254,0,0},
{8,4,2,4,8,0},
{256,256,256,256,256,0},
{0,0,1,2,0,0},
{64,168,168,168,240,0},
{254,80,136,136,112,0},
{112,136,136,136,80,0},
{112,136,136,80,254,0},
{112,168,168,168,48,0},
{16,252,18,18,4,0},
{304,584,584,584,504,0},
{254,16,8,8,240,0},
{0,136,250,128,0,0},
{0,384,512,520,506,0},
{254,32,32,80,136,0},
{0,130,254,128,0,0},
{248,8,112,8,240,0},
{248,16,8,8,240,0},
{112,136,136,136,112,0},
{1016,80,136,136,112,0},
{112,136,136,80,1016,0},
{248,16,8,8,16,0},
{144,168,168,168,64,0},
{8,126,136,136,64,0},
{120,128,128,64,248,0},
{24,96,128,96,24,0},
{120,128,96,128,120,0},
{136,80,32,80,136,0},
{312,576,576,544,504,0},
{136,200,168,152,136,0},
{0,16,84,170,130,0},
{0,0,254,0,0,0},
{0,130,170,84,16,0},
{12,2,4,8,6,0},
},Extra:projectFontExtraROM[:]}

func gluNumberDivFraction(n rt.Number, divisor uint32) rt.Number {
	magnitude := uint32(n)
	if n < 0 { magnitude = 0 - magnitude }
	quotient := magnitude / divisor
	remainder := magnitude - quotient * divisor
	result := (quotient << 16) + ((remainder << 16) / divisor)
	if n < 0 { result = 0 - result }
	return rt.Number(result)
}
func gluValueDivFraction(a rt.Value, divisor uint32) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(gluNumberDivFraction(a.Num, divisor))
}
func gluNumberDivReciprocal(n rt.Number, multiplier, divisor uint32) rt.Number {
	magnitude := uint32(n)
	if n < 0 { magnitude = 0 - magnitude }
	quotient := uint32((uint64(magnitude) * uint64(multiplier)) >> 32)
	if uint64(quotient) * uint64(divisor) > uint64(magnitude) << 16 { quotient-- }
	if n < 0 { quotient = 0 - quotient }
	return rt.Number(quotient)
}
func gluValueDivReciprocal(a rt.Value, multiplier, divisor uint32) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(gluNumberDivReciprocal(a.Num, multiplier, divisor))
}
func gluNumberDivThreeHalves(n rt.Number) rt.Number {
	magnitude := uint32(n)
	if n < 0 { magnitude = 0 - magnitude }
	quotient := rt.Number(uint32((uint64(magnitude) * 0xaaaaaaab) >> 32))
	if n < 0 { return -quotient }
	return quotient
}
func gluNumberDivPow2(n rt.Number, shift int) rt.Number {
	if n >= 0 { return n >> shift }
	return (n + (1 << shift) - 1) >> shift
}
func gluNumberModPow2(n rt.Number, shift int) rt.Number {
	return n - ((n >> shift) << shift)
}
func gluNumberModLit(n rt.Number, z int32) rt.Number {
	if z == 0 { return 0 }
	r := n % rt.Number(z)
	if r != 0 && ((r < 0) != (z < 0)) { r += rt.Number(z) }
	return r
}
func gluValueDivThreeHalves(a rt.Value) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(gluNumberDivThreeHalves(a.Num))
}
func gluValueDivPow2(a rt.Value, shift int) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(gluNumberDivPow2(a.Num, shift))
}
func gluValueMulPow2(a rt.Value, shift int) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(a.Num << shift)
}
func gluValueDivInt(a rt.Value, k int32) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(rt.Number(int32(a.Num) / k))
}
func gluValueIDivInt(a rt.Value, k int32) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(rt.Number(int32(a.Num) / k).Flr())
}
func gluValueDivLit(a rt.Value, d int32) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(rt.Number((int64(a.Num) << 16) / int64(d)))
}
func gluValueModLit(a rt.Value, z int32) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(gluNumberModLit(a.Num, z))
}
func gluValueModPow2(a rt.Value, shift int) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(gluNumberModPow2(a.Num, shift))
}
func gluValueNegNumber(a rt.Value) rt.Value {
	if a.Kind != rt.KindNumber { return rt.NilVal() }
	return rt.NumVal(-a.Num)
}
//go:noinline
func gluPushRoots(c *rt.Context, roots ...rt.Value) int {
	n := 0
	for _, root := range roots {
		if root.Kind != rt.KindTable && root.Kind != rt.KindString { continue }
		if !c.PushLocal(root) { c.PopLocals(n); return -1 }
		n++
	}
	return n
}
func gluPopRoots(c *rt.Context, n int) { if n > 0 { c.PopLocals(n) } }
func gluMust(v rt.Value, err rt.HeapError) rt.Value { if err != rt.HeapOK { return rt.NilVal() }; return v }
func gluCmp(c *rt.Context, a, z rt.Value, op string) bool {
	cmp := 0
	if a.Kind == rt.KindNumber && z.Kind == rt.KindNumber { if a.Num < z.Num { cmp = -1 } else if a.Num > z.Num { cmp = 1 } } else { var ok bool; cmp, ok = c.CompareStrings(a,z); if !ok { return false } }
	switch op { case "<": return cmp < 0; case "<=": return cmp <= 0; case ">": return cmp > 0; case ">=": return cmp >= 0 }; return false
}
func gluLen(c *rt.Context, v rt.Value) rt.Value { if v.Kind == rt.KindString || v.Kind == rt.KindStaticString { return rt.IntVal(c.StrLen(v)) }; if v.Kind == rt.KindTable { return rt.IntVal(c.TableLen(v)) }; return rt.IntVal(0) }
func gluNumberMod(a, z rt.Number) rt.Number { return a.Mod(z) }
func gluMod(a, z rt.Value) rt.Value { if a.Kind != rt.KindNumber || z.Kind != rt.KindNumber { return rt.NilVal() }; return rt.NumVal(gluNumberMod(a.Num,z.Num)) }
func gluNumberPow(a, z rt.Number) rt.Number { n := z.Int(); if n == 0 { return rt.One }; neg := n < 0; if neg { n = -n }; out := rt.One; for n > 0 { if n&1 != 0 { out = out.Mul(a) }; a = a.Mul(a); n >>= 1 }; if neg { out = rt.One.Div(out) }; return out }
func gluPow(a, z rt.Value) rt.Value { if a.Kind != rt.KindNumber || z.Kind != rt.KindNumber { return rt.NilVal() }; return rt.NumVal(gluNumberPow(a.Num,z.Num)) }
func gluConcat(c *rt.Context, a, z rt.Value, roots ...rt.Value) rt.Value { n := gluPushRoots(c, a, z); if n < 0 { return rt.NilVal() }; m := gluPushRoots(c, roots...); if m < 0 { gluPopRoots(c,n); return rt.NilVal() }; v, err := c.Concat(a,z); gluPopRoots(c,n+m); return gluMust(v,err) }
func gluSub(c *rt.Context, s, i, j rt.Value, roots ...rt.Value) rt.Value { n := gluPushRoots(c,s,i,j); if n < 0 { return rt.NilVal() }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,n); return rt.NilVal() }; v,err := c.Sub(s,i,j); gluPopRoots(c,n+m); return gluMust(v,err) }
func gluChr(c *rt.Context, n rt.Value, roots ...rt.Value) rt.Value { k := gluPushRoots(c,n); if k < 0 { return rt.NilVal() }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,k); return rt.NilVal() }; v,err := c.Chr(n); gluPopRoots(c,k+m); return gluMust(v,err) }
func gluTostr(c *rt.Context, v rt.Value, hex bool, roots ...rt.Value) rt.Value { k := gluPushRoots(c,v); if k < 0 { return rt.NilVal() }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,k); return rt.NilVal() }; out,err := c.Tostr(v,hex); gluPopRoots(c,k+m); return gluMust(out,err) }
func gluTableAdd(c *rt.Context, t, v, i rt.Value, roots ...rt.Value) rt.HeapError { n := gluPushRoots(c,t,v,i); if n < 0 { return rt.HeapOOM }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,n); return rt.HeapOOM }; err := c.TableAdd(t,v,i); gluPopRoots(c,n+m); return err }
func gluTableAppendKnown(c *rt.Context, t, v rt.Value, at int, roots ...rt.Value) rt.HeapError { n := gluPushRoots(c,t,v); if n < 0 { return rt.HeapOOM }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,n); return rt.HeapOOM }; err := c.TableAppendKnown(t,v,at); gluPopRoots(c,n+m); return err }
func gluTableAppendKnownHeld(c *rt.Context, t, v rt.Value, at int, roots ...rt.Value) rt.HeapError { n := gluPushRoots(c,v); if n < 0 { return rt.HeapOOM }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,n); return rt.HeapOOM }; err := c.TableAppendKnown(t,v,at); gluPopRoots(c,n+m); return err }
func gluTableSet(c *rt.Context, t, k, v rt.Value, roots ...rt.Value) rt.HeapError { n := gluPushRoots(c,t,k,v); if n < 0 { return rt.HeapOOM }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,n); return rt.HeapOOM }; err := c.TableSet(t,k,v); gluPopRoots(c,n+m); return err }
func gluTableSetStable(c *rt.Context, t, k, v rt.Value, cache *rt.TableFieldCache, roots ...rt.Value) rt.HeapError { if *cache != 0 { return c.TableSetStable(t,k,v,cache) }; n := gluPushRoots(c,t,k,v); if n < 0 { return rt.HeapOOM }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,n); return rt.HeapOOM }; err := c.TableSetStable(t,k,v,cache); gluPopRoots(c,n+m); return err }
func gluTableSetStableNumber(c *rt.Context, t, k rt.Value, v rt.Number, cache *rt.TableFieldCache, roots ...rt.Value) rt.HeapError { if *cache != 0 { return c.TableSetStableNumber(t,k,v,cache) }; n := gluPushRoots(c,t,k); if n < 0 { return rt.HeapOOM }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,n); return rt.HeapOOM }; err := c.TableSetStableNumber(t,k,v,cache); gluPopRoots(c,n+m); return err }
func gluPrintV(c *rt.Context, s, x, y, color rt.Value, roots ...rt.Value) int { n := gluPushRoots(c,s,x,y,color); if n < 0 { return x.Int() }; m := gluPushRoots(c,roots...); if m < 0 { gluPopRoots(c,n); return x.Int() }; out := c.PrintV(s,x,y,color); gluPopRoots(c,n+m); return out }

const (
	SheetW = 64; SheetH = 64; MapW = 32; MapH = 32; MapLayers = 4; MapPlaneMask = 1; MapStreaming = false; SheetReadOnly = true
	SpriteCols = SheetW / 8; SpriteRows = SheetH / 8; SpriteN = SpriteCols * SpriteRows
)

//go:section .rodata
var sheetROM = [ 4032 ]byte{0x05,0x05,0x06,0x06,0x07,0x07,0x00,0x08,0x05,0x05,0x06,0x06,0x07,0x00,0x08,0x08,0x06,0x06,0x07,0x07,0x00,0x08,0x09,0x09,0x06,0x06,0x07,0x00,0x08,0x08,0x09,0x09,0x07,0x07,0x00,0x08,0x09,0x09,0x0a,0x0a,0x07,0x00,0x08,0x08,0x09,0x09,0x0a,0x0a,0x00,0x08,0x09,0x09,0x0a,0x0a,0x0b,0x00,0x08,0x08,0x09,0x09,0x0a,0x0a,0x00,0x0b,0x08,0x08,0x09,0x09,0x0a,0x00,0x0b,0x0b,0x08,0x08,0x09,0x09,0x00,0x0a,0x0b,0x0b,0x09,0x09,0x0a,0x00,0x0b,0x0b,0x0c,0x0c,0x09,0x09,0x00,0x0a,0x0b,0x0b,0x0c,0x0c,0x0a,0x00,0x0b,0x0b,0x0c,0x0c,0x0d,0x0d,0x00,0x0a,0x0b,0x0b,0x0c,0x0c,0x0d,0x00,0x0b,0x0b,0x0c,0x0c,0x0d,0x0d,0x00,0x0e,0x0b,0x0b,0x0c,0x0c,0x0d,0x00,0x0e,0x0e,0x0b,0x0b,0x0c,0x0c,0x00,0x0d,0x0e,0x0e,0x0b,0x0b,0x0c,0x00,0x0d,0x0d,0x0e,0x0e,0x0c,0x0c,0x00,0x0d,0x0e,0x0e,0x0f,0x0f,0x0c,0x00,0x0d,0x0d,0x0e,0x0e,0x0f,0x0f,0x00,0x0d,0x0e,0x0e,0x0f,0x0f,0x10,0x00,0x0d,0x0d,0x0e,0x0e,0x0f,0x0f,0x00,0x10,0x0e,0x0e,0x0f,0x0f,0x10,0x00,0x11,0x11,0x0e,0x0e,0x0f,0x0f,0x00,0x10,0x11,0x11,0x0e,0x0e,0x0f,0x00,0x10,0x10,0x11,0x11,0x0e,0x0e,0x00,0x0f,0x10,0x10,0x11,0x11,0x0f,0x00,0x10,0x10,0x11,0x11,0x12,0x12,0x00,0x0f,0x10,0x10,0x11,0x11,0x12,0x00,0x10,0x10,0x11,0x11,0x12,0x12,0x00,0x13,0x10,0x10,0x11,0x11,0x12,0x00,0x13,0x13,0x11,0x11,0x12,0x12,0x00,0x13,0x14,0x14,0x11,0x11,0x12,0x00,0x13,0x13,0x14,0x14,0x11,0x11,0x00,0x12,0x13,0x13,0x14,0x14,0x11,0x00,0x12,0x12,0x13,0x13,0x14,0x14,0x00,0x12,0x13,0x13,0x14,0x14,0x15,0x00,0x12,0x12,0x13,0x13,0x14,0x14,0x00,0x15,0x13,0x13,0x14,0x14,0x15,0x00,0x16,0x16,0x13,0x13,0x14,0x14,0x00,0x15,0x16,0x16,0x14,0x14,0x15,0x00,0x16,0x16,0x17,0x17,0x14,0x14,0x00,0x15,0x16,0x16,0x17,0x17,0x14,0x00,0x15,0x15,0x16,0x16,0x17,0x17,0x00,0x14,0x15,0x15,0x16,0x16,0x17,0x00,0x15,0x15,0x16,0x16,0x17,0x17,0x00,0x18,0x15,0x15,0x16,0x16,0x17,0x00,0x18,0x18,0x16,0x16,0x17,0x17,0x00,0x18,0x19,0x19,0x16,0x16,0x17,0x00,0x18,0x18,0x19,0x19,0x17,0x17,0x00,0x18,0x19,0x19,0x1a,0x1a,0x17,0x00,0x18,0x18,0x19,0x19,0x1a,0x1a,0x00,0x17,0x18,0x18,0x19,0x19,0x1a,0x00,0x17,0x17,0x18,0x18,0x19,0x19,0x00,0x1a,0x18,0x18,0x19,0x19,0x1a,0x00,0x1b,0x1b,0x18,0x18,0x19,0x19,0x00,0x1a,0x1b,0x1b,0x19,0x19,0x1a,0x00,0x1b,0x1b,0x1c,0x1c,0x19,0x19,0x00,0x1a,0x1b,0x1b,0x1c,0x1c,0x1a,0x00,0x1b,0x1b,0x1c,0x1c,0x1d,0x1d,0x00,0x1a,0x1b,0x1b,0x1c,0x1c,0x1d,0x00,0x1a,0x1a,0x1b,0x1b,0x1c,0x1c,0x00,0x1d,0x1a,0x1a,0x1b,0x1b,0x1c,0x00,0x1d,0x1d,0x1b,0x1b,0x1c,0x1c,0x00,0x1d,0x1e,0x1e,0x1b,0x1b,0x1c,0x00,0x1d,0x1d,0x1e,0x1e,0x1c,0x1c,0x00,0x1d,0x1e,0x1e,0x1f,0x1f,0x1c,0x00,0x1d,0x1d,0x1e,0x1e,0x1f,0x1f,0x00,0x1d,0x1e,0x1e,0x1f,0x1f,0x02,0x00,0x1d,0x1d,0x1e,0x1e,0x1f,0x1f,0x00,0x02,0x1d,0x1d,0x1e,0x1e,0x1f,0x00,0x02,0x02,0x1d,0x1d,0x1e,0x1e,0x00,0x1f,0x02,0x02,0x1e,0x1e,0x1f,0x00,0x02,0x02,0x03,0x03,0x1e,0x1e,0x00,0x1f,0x02,0x02,0x03,0x03,0x1f,0x00,0x02,0x02,0x03,0x03,0x04,0x04,0x00,0x1f,0x02,0x02,0x03,0x03,0x04,0x00,0x02,0x02,0x03,0x03,0x04,0x04,0x00,0x05,0x02,0x02,0x03,0x03,0x04,0x00,0x05,0x05,0x02,0x02,0x03,0x03,0x00,0x04,0x05,0x05,0x02,0x02,0x03,0x00,0x04,0x04,0x05,0x05,0x03,0x03,0x00,0x04,0x05,0x05,0x06,0x06,0x03,0x00,0x04,0x04,0x05,0x05,0x06,0x06,0x00,0x04,0x05,0x05,0x06,0x06,0x07,0x00,0x04,0x04,0x05,0x05,0x06,0x06,0x00,0x07,0x05,0x05,0x06,0x06,0x07,0x00,0x08,0x08,0x05,0x05,0x06,0x06,0x00,0x07,0x08,0x08,0x05,0x05,0x06,0x00,0x07,0x07,0x08,0x08,0x05,0x05,0x00,0x06,0x07,0x07,0x08,0x08,0x06,0x00,0x07,0x07,0x08,0x08,0x09,0x09,0x00,0x06,0x07,0x07,0x08,0x08,0x09,0x00,0x07,0x07,0x08,0x08,0x09,0x09,0x00,0x0a,0x07,0x07,0x08,0x08,0x09,0x00,0x0a,0x0a,0x08,0x08,0x09,0x09,0x00,0x0a,0x0b,0x0b,0x08,0x08,0x09,0x00,0x0a,0x0a,0x0b,0x0b,0x08,0x08,0x00,0x09,0x0a,0x0a,0x0b,0x0b,0x08,0x00,0x09,0x09,0x0a,0x0a,0x0b,0x0b,0x00,0x09,0x0a,0x0a,0x0b,0x0b,0x0c,0x00,0x09,0x09,0x0a,0x0a,0x0b,0x0b,0x00,0x0c,0x0a,0x0a,0x0b,0x0b,0x0c,0x00,0x0d,0x0d,0x0a,0x0a,0x0b,0x0b,0x00,0x0c,0x0d,0x0d,0x0b,0x0b,0x0c,0x00,0x0d,0x0d,0x0e,0x0e,0x0b,0x0b,0x00,0x0c,0x0d,0x0d,0x0e,0x0e,0x0b,0x00,0x0c,0x0c,0x0d,0x0d,0x0e,0x0e,0x00,0x0b,0x0c,0x0c,0x0d,0x0d,0x0e,0x00,0x0c,0x0c,0x0d,0x0d,0x0e,0x0e,0x00,0x0f,0x0c,0x0c,0x0d,0x0d,0x0e,0x00,0x0f,0x0f,0x0d,0x0d,0x0e,0x0e,0x00,0x0f,0x10,0x10,0x0d,0x0d,0x0e,0x00,0x0f,0x0f,0x10,0x10,0x0e,0x0e,0x00,0x0f,0x10,0x10,0x11,0x11,0x0e,0x00,0x0f,0x0f,0x10,0x10,0x11,0x11,0x00,0x0e,0x0f,0x0f,0x10,0x10,0x11,0x00,0x0e,0x0e,0x0f,0x0f,0x10,0x10,0x00,0x11,0x0f,0x0f,0x10,0x10,0x11,0x00,0x12,0x12,0x0f,0x0f,0x10,0x10,0x00,0x11,0x12,0x12,0x10,0x10,0x11,0x00,0x12,0x12,0x13,0x13,0x10,0x10,0x00,0x11,0x12,0x12,0x13,0x13,0x11,0x00,0x12,0x12,0x13,0x13,0x14,0x14,0x00,0x11,0x12,0x12,0x13,0x13,0x14,0x00,0x11,0x11,0x12,0x12,0x13,0x13,0x00,0x14,0x11,0x11,0x12,0x12,0x13,0x00,0x14,0x14,0x12,0x12,0x13,0x13,0x00,0x14,0x15,0x15,0x12,0x12,0x13,0x00,0x14,0x14,0x15,0x15,0x13,0x13,0x00,0x14,0x15,0x15,0x16,0x16,0x13,0x00,0x14,0x14,0x15,0x15,0x16,0x16,0x00,0x14,0x15,0x15,0x16,0x16,0x17,0x00,0x14,0x14,0x15,0x15,0x16,0x16,0x00,0x17,0x14,0x14,0x15,0x15,0x16,0x00,0x17,0x17,0x14,0x14,0x15,0x15,0x00,0x16,0x17,0x17,0x15,0x15,0x16,0x00,0x17,0x17,0x18,0x18,0x15,0x15,0x00,0x16,0x17,0x17,0x18,0x18,0x16,0x00,0x17,0x17,0x18,0x18,0x19,0x19,0x00,0x16,0x17,0x17,0x18,0x18,0x19,0x00,0x17,0x17,0x18,0x18,0x19,0x19,0x00,0x1a,0x17,0x17,0x18,0x18,0x19,0x00,0x1a,0x1a,0x17,0x17,0x18,0x18,0x00,0x19,0x1a,0x1a,0x17,0x17,0x18,0x00,0x19,0x19,0x1a,0x1a,0x18,0x18,0x00,0x19,0x1a,0x1a,0x1b,0x1b,0x18,0x00,0x19,0x19,0x1a,0x1a,0x1b,0x1b,0x00,0x19,0x1a,0x1a,0x1b,0x1b,0x1c,0x00,0x19,0x19,0x1a,0x1a,0x1b,0x1b,0x00,0x1c,0x1a,0x1a,0x1b,0x1b,0x1c,0x00,0x1d,0x1d,0x1a,0x1a,0x1b,0x1b,0x00,0x1c,0x1d,0x1d,0x1a,0x1a,0x1b,0x00,0x1c,0x1c,0x1d,0x1d,0x1a,0x1a,0x00,0x1b,0x1c,0x1c,0x1d,0x1d,0x1b,0x00,0x1c,0x1c,0x1d,0x1d,0x1e,0x1e,0x00,0x1b,0x1c,0x1c,0x1d,0x1d,0x1e,0x00,0x1c,0x1c,0x1d,0x1d,0x1e,0x1e,0x00,0x1f,0x1c,0x1c,0x1d,0x1d,0x1e,0x00,0x1f,0x1f,0x1d,0x1d,0x1e,0x1e,0x00,0x1f,0x02,0x02,0x1d,0x1d,0x1e,0x00,0x1f,0x1f,0x02,0x02,0x1d,0x1d,0x00,0x1e,0x1f,0x1f,0x02,0x02,0x1d,0x00,0x1e,0x1e,0x1f,0x1f,0x02,0x02,0x00,0x1e,0x1f,0x1f,0x02,0x02,0x03,0x00,0x1e,0x1e,0x1f,0x1f,0x02,0x02,0x00,0x03,0x1f,0x1f,0x02,0x02,0x03,0x00,0x04,0x04,0x1f,0x1f,0x02,0x02,0x00,0x03,0x04,0x04,0x02,0x02,0x03,0x00,0x04,0x04,0x05,0x05,0x02,0x02,0x00,0x03,0x04,0x04,0x05,0x05,0x02,0x00,0x03,0x03,0x04,0x04,0x05,0x05,0x00,0x02,0x03,0x03,0x04,0x04,0x05,0x00,0x03,0x03,0x04,0x04,0x05,0x05,0x00,0x06,0x03,0x03,0x04,0x04,0x05,0x00,0x06,0x06,0x04,0x04,0x05,0x05,0x00,0x06,0x07,0x07,0x04,0x04,0x05,0x00,0x06,0x06,0x07,0x07,0x05,0x05,0x00,0x06,0x07,0x07,0x08,0x08,0x05,0x00,0x06,0x06,0x07,0x07,0x08,0x08,0x00,0x05,0x06,0x06,0x07,0x07,0x08,0x00,0x05,0x05,0x06,0x06,0x07,0x07,0x00,0x08,0x06,0x06,0x07,0x07,0x08,0x00,0x09,0x09,0x06,0x06,0x07,0x07,0x00,0x08,0x09,0x09,0x07,0x07,0x08,0x00,0x09,0x09,0x0a,0x0a,0x07,0x07,0x00,0x08,0x09,0x09,0x0a,0x0a,0x08,0x00,0x09,0x09,0x0a,0x0a,0x0b,0x0b,0x00,0x08,0x09,0x09,0x0a,0x0a,0x0b,0x00,0x08,0x08,0x09,0x09,0x0a,0x0a,0x00,0x0b,0x08,0x08,0x09,0x09,0x0a,0x00,0x0b,0x0b,0x09,0x09,0x0a,0x0a,0x00,0x0b,0x0c,0x0c,0x09,0x09,0x0a,0x00,0x0b,0x0b,0x0c,0x0c,0x0a,0x0a,0x00,0x0b,0x0c,0x0c,0x0d,0x0d,0x0a,0x00,0x0b,0x0b,0x0c,0x0c,0x0d,0x0d,0x00,0x0b,0x0c,0x0c,0x0d,0x0d,0x0e,0x00,0x0b,0x0b,0x0c,0x0c,0x0d,0x0d,0x00,0x0e,0x0b,0x0b,0x0c,0x0c,0x0d,0x00,0x0e,0x0e,0x0b,0x0b,0x0c,0x0c,0x00,0x0d,0x0e,0x0e,0x0c,0x0c,0x0d,0x00,0x0e,0x0e,0x0f,0x0f,0x0c,0x0c,0x00,0x0d,0x0e,0x0e,0x0f,0x0f,0x0d,0x00,0x0e,0x0e,0x0f,0x0f,0x10,0x10,0x00,0x0d,0x0e,0x0e,0x0f,0x0f,0x10,0x00,0x0e,0x0e,0x0f,0x0f,0x10,0x10,0x00,0x11,0x0e,0x0e,0x0f,0x0f,0x10,0x00,0x11,0x11,0x0e,0x0e,0x0f,0x0f,0x00,0x10,0x11,0x11,0x0e,0x0e,0x0f,0x00,0x10,0x10,0x11,0x11,0x0f,0x0f,0x00,0x10,0x11,0x11,0x12,0x12,0x0f,0x00,0x10,0x10,0x11,0x11,0x12,0x12,0x00,0x10,0x11,0x11,0x12,0x12,0x13,0x00,0x10,0x10,0x11,0x11,0x12,0x12,0x00,0x13,0x11,0x11,0x12,0x12,0x13,0x00,0x14,0x14,0x11,0x11,0x12,0x12,0x00,0x13,0x14,0x14,0x11,0x11,0x12,0x00,0x13,0x13,0x14,0x14,0x11,0x11,0x00,0x12,0x13,0x13,0x14,0x14,0x12,0x00,0x13,0x13,0x14,0x14,0x15,0x15,0x00,0x12,0x13,0x13,0x14,0x14,0x15,0x00,0x13,0x13,0x14,0x14,0x15,0x15,0x00,0x16,0x13,0x13,0x14,0x14,0x15,0x00,0x16,0x16,0x14,0x14,0x15,0x15,0x00,0x16,0x17,0x17,0x14,0x14,0x15,0x00,0x16,0x16,0x17,0x17,0x14,0x14,0x00,0x15,0x16,0x16,0x17,0x17,0x14,0x00,0x15,0x15,0x16,0x16,0x17,0x17,0x00,0x15,0x16,0x16,0x17,0x17,0x18,0x00,0x15,0x15,0x16,0x16,0x17,0x17,0x00,0x18,0x16,0x16,0x17,0x17,0x18,0x00,0x19,0x19,0x16,0x16,0x17,0x17,0x00,0x18,0x19,0x19,0x17,0x17,0x18,0x00,0x19,0x19,0x1a,0x1a,0x17,0x17,0x00,0x18,0x19,0x19,0x1a,0x1a,0x17,0x00,0x18,0x18,0x19,0x19,0x1a,0x1a,0x00,0x17,0x18,0x18,0x19,0x19,0x1a,0x00,0x18,0x18,0x19,0x19,0x1a,0x1a,0x00,0x1b,0x18,0x18,0x19,0x19,0x1a,0x00,0x1b,0x1b,0x19,0x19,0x1a,0x1a,0x00,0x1b,0x1c,0x1c,0x19,0x19,0x1a,0x00,0x1b,0x1b,0x1c,0x1c,0x1a,0x1a,0x00,0x1b,0x1c,0x1c,0x1d,0x1d,0x1a,0x00,0x1b,0x1b,0x1c,0x1c,0x1d,0x1d,0x00,0x1a,0x1b,0x1b,0x1c,0x1c,0x1d,0x00,0x1a,0x1a,0x1b,0x1b,0x1c,0x1c,0x00,0x1d,0x1b,0x1b,0x1c,0x1c,0x1d,0x00,0x1e,0x1e,0x1b,0x1b,0x1c,0x1c,0x00,0x1d,0x1e,0x1e,0x1c,0x1c,0x1d,0x00,0x1e,0x1e,0x1f,0x1f,0x1c,0x1c,0x00,0x1d,0x1e,0x1e,0x1f,0x1f,0x1d,0x00,0x1e,0x1e,0x1f,0x1f,0x02,0x02,0x00,0x1d,0x1e,0x1e,0x1f,0x1f,0x02,0x00,0x1d,0x1d,0x1e,0x1e,0x1f,0x1f,0x00,0x02,0x1d,0x1d,0x1e,0x1e,0x1f,0x00,0x02,0x02,0x1e,0x1e,0x1f,0x1f,0x00,0x02,0x03,0x03,0x1e,0x1e,0x1f,0x00,0x02,0x02,0x03,0x03,0x1f,0x1f,0x00,0x02,0x03,0x03,0x04,0x04,0x1f,0x00,0x02,0x02,0x03,0x03,0x04,0x04,0x00,0x02,0x03,0x03,0x04,0x04,0x05,0x00,0x02,0x02,0x03,0x03,0x04,0x04,0x00,0x05,0x02,0x02,0x03,0x03,0x04,0x00,0x05,0x05,0x02,0x02,0x03,0x03,0x00,0x04,0x05,0x05,0x03,0x03,0x04,0x00,0x05,0x05,0x06,0x06,0x03,0x03,0x00,0x04,0x05,0x05,0x06,0x06,0x04,0x00,0x05,0x05,0x06,0x06,0x07,0x07,0x00,0x04,0x05,0x05,0x06,0x06,0x07,0x00,0x05,0x05,0x06,0x06,0x07,0x07,0x00,0x08,0x05,0x05,0x06,0x06,0x07,0x00,0x08,0x08,0x05,0x05,0x06,0x06,0x00,0x07,0x08,0x08,0x05,0x05,0x06,0x00,0x07,0x07,0x08,0x08,0x06,0x06,0x00,0x07,0x08,0x08,0x09,0x09,0x06,0x00,0x07,0x07,0x08,0x08,0x09,0x09,0x00,0x07,0x08,0x08,0x09,0x09,0x0a,0x00,0x07,0x07,0x08,0x08,0x09,0x09,0x00,0x0a,0x08,0x08,0x09,0x09,0x0a,0x00,0x0b,0x0b,0x08,0x08,0x09,0x09,0x00,0x0a,0x0b,0x0b,0x08,0x08,0x09,0x00,0x0a,0x0a,0x0b,0x0b,0x08,0x08,0x00,0x09,0x0a,0x0a,0x0b,0x0b,0x09,0x00,0x0a,0x0a,0x0b,0x0b,0x0c,0x0c,0x00,0x09,0x0a,0x0a,0x0b,0x0b,0x0c,0x00,0x0a,0x0a,0x0b,0x0b,0x0c,0x0c,0x00,0x0d,0x0a,0x0a,0x0b,0x0b,0x0c,0x00,0x0d,0x0d,0x0b,0x0b,0x0c,0x0c,0x00,0x0d,0x0e,0x0e,0x0b,0x0b,0x0c,0x00,0x0d,0x0d,0x0e,0x0e,0x0b,0x0b,0x00,0x0c,0x0d,0x0d,0x0e,0x0e,0x0b,0x00,0x0c,0x0c,0x0d,0x0d,0x0e,0x0e,0x00,0x0c,0x0d,0x0d,0x0e,0x0e,0x0f,0x00,0x0c,0x0c,0x0d,0x0d,0x0e,0x0e,0x00,0x0f,0x0d,0x0d,0x0e,0x0e,0x0f,0x00,0x10,0x10,0x0d,0x0d,0x0e,0x0e,0x00,0x0f,0x10,0x10,0x0e,0x0e,0x0f,0x00,0x10,0x10,0x11,0x11,0x0e,0x0e,0x00,0x0f,0x10,0x10,0x11,0x11,0x0e,0x00,0x0f,0x0f,0x10,0x10,0x11,0x11,0x00,0x0e,0x0f,0x0f,0x10,0x10,0x11,0x00,0x0f,0x0f,0x10,0x10,0x11,0x11,0x00,0x12,0x0f,0x0f,0x10,0x10,0x11,0x00,0x12,0x12,0x10,0x10,0x11,0x11,0x00,0x12,0x13,0x13,0x10,0x10,0x11,0x00,0x12,0x12,0x13,0x13,0x11,0x11,0x00,0x12,0x13,0x13,0x14,0x14,0x11,0x00,0x12,0x12,0x13,0x13,0x14,0x14,0x00,0x11,0x12,0x12,0x13,0x13,0x14,0x00,0x11,0x11,0x12,0x12,0x13,0x13,0x00,0x14,0x12,0x12,0x13,0x13,0x14,0x00,0x15,0x15,0x12,0x12,0x13,0x13,0x00,0x14,0x15,0x15,0x13,0x13,0x14,0x00,0x15,0x15,0x16,0x16,0x13,0x13,0x00,0x14,0x15,0x15,0x16,0x16,0x14,0x00,0x15,0x15,0x16,0x16,0x17,0x17,0x00,0x14,0x15,0x15,0x16,0x16,0x17,0x00,0x14,0x14,0x15,0x15,0x16,0x16,0x00,0x17,0x14,0x14,0x15,0x15,0x16,0x00,0x17,0x17,0x15,0x15,0x16,0x16,0x00,0x17,0x18,0x18,0x15,0x15,0x16,0x00,0x17,0x17,0x18,0x18,0x16,0x16,0x00,0x17,0x18,0x18,0x19,0x19,0x16,0x00,0x17,0x17,0x18,0x18,0x19,0x19,0x00,0x17,0x18,0x18,0x19,0x19,0x1a,0x00,0x17,0x17,0x18,0x18,0x19,0x19,0x00,0x1a,0x17,0x17,0x18,0x18,0x19,0x00,0x1a,0x1a,0x17,0x17,0x18,0x18,0x00,0x19,0x1a,0x1a,0x18,0x18,0x19,0x00,0x1a,0x1a,0x1b,0x1b,0x18,0x18,0x00,0x19,0x1a,0x1a,0x1b,0x1b,0x19,0x00,0x1a,0x1a,0x1b,0x1b,0x1c,0x1c,0x00,0x19,0x1a,0x1a,0x1b,0x1b,0x1c,0x00,0x1a,0x1a,0x1b,0x1b,0x1c,0x1c,0x00,0x1d,0x1a,0x1a,0x1b,0x1b,0x1c,0x00,0x1d,0x1d,0x1a,0x1a,0x1b,0x1b,0x00,0x1c,0x1d,0x1d,0x1a,0x1a,0x1b,0x00,0x1c,0x1c,0x1d,0x1d,0x1b,0x1b,0x00,0x1c,0x1d,0x1d,0x1e,0x1e,0x1b,0x00,0x1c,0x1c,0x1d,0x1d,0x1e,0x1e,0x00,0x1c,0x1d,0x1d,0x1e,0x1e,0x1f,0x00,0x1c,0x1c,0x1d,0x1d,0x1e,0x1e,0x00,0x1f,0x1d,0x1d,0x1e,0x1e,0x1f,0x00,0x02,0x02,0x1d,0x1d,0x1e,0x1e,0x00,0x1f,0x02,0x02,0x1d,0x1d,0x1e,0x00,0x1f,0x1f,0x02,0x02,0x1d,0x1d,0x00,0x1e,0x1f,0x1f,0x02,0x02,0x1e,0x00,0x1f,0x1f,0x02,0x02,0x03,0x03,0x00,0x1e,0x1f,0x1f,0x02,0x02,0x03,0x00,0x1f,0x1f,0x02,0x02,0x03,0x03,0x00,0x04,0x1f,0x1f,0x02,0x02,0x03,0x00,0x04,0x04,0x02,0x02,0x03,0x03,0x00,0x04,0x05,0x05,0x02,0x02,0x03,0x00,0x04,0x04,0x05,0x05,0x02,0x02,0x00,0x03,0x04,0x04,0x05,0x05,0x02,0x00,0x03,0x03,0x04,0x04,0x05,0x05,0x00,0x03,0x04,0x04,0x05,0x05,0x06,0x00,0x03,0x03,0x04,0x04,0x05,0x05,0x00,0x06,0x04,0x04,0x05,0x05,0x06,0x00,0x07,0x07,0x04,0x04,0x05,0x05,0x00,0x06,0x07,0x07,0x05,0x05,0x06,0x00,0x07,0x07,0x08,0x08,0x05,0x05,0x00,0x06,0x07,0x07,0x08,0x08,0x05,0x00,0x06,0x06,0x07,0x07,0x08,0x08,0x00,0x05,0x06,0x06,0x07,0x07,0x08,0x00,0x06,0x06,0x07,0x07,0x08,0x08,0x00,0x09,0x06,0x06,0x07,0x07,0x08,0x00,0x09,0x09,0x07,0x07,0x08,0x08,0x00,0x09,0x0a,0x0a,0x07,0x07,0x08,0x00,0x09,0x09,0x0a,0x0a,0x08,0x08,0x00,0x09,0x0a,0x0a,0x0b,0x0b,0x08,0x00,0x09,0x09,0x0a,0x0a,0x0b,0x0b,0x00,0x08,0x09,0x09,0x0a,0x0a,0x0b,0x00,0x08,0x08,0x09,0x09,0x0a,0x0a,0x00,0x0b,0x09,0x09,0x0a,0x0a,0x0b,0x00,0x0c,0x0c,0x09,0x09,0x0a,0x0a,0x00,0x0b,0x0c,0x0c,0x0a,0x0a,0x0b,0x00,0x0c,0x0c,0x0d,0x0d,0x0a,0x0a,0x00,0x0b,0x0c,0x0c,0x0d,0x0d,0x0b,0x00,0x0c,0x0c,0x0d,0x0d,0x0e,0x0e,0x00,0x0b,0x0c,0x0c,0x0d,0x0d,0x0e,0x00,0x0b,0x0b,0x0c,0x0c,0x0d,0x0d,0x00,0x0e,0x0b,0x0b,0x0c,0x0c,0x0d,0x00,0x0e,0x0e,0x0c,0x0c,0x0d,0x0d,0x00,0x0e,0x0f,0x0f,0x0c,0x0c,0x0d,0x00,0x0e,0x0e,0x0f,0x0f,0x0d,0x0d,0x00,0x0e,0x0f,0x0f,0x10,0x10,0x0d,0x00,0x0e,0x0e,0x0f,0x0f,0x10,0x10,0x00,0x0e,0x0f,0x0f,0x10,0x10,0x11,0x00,0x0e,0x0e,0x0f,0x0f,0x10,0x10,0x00,0x11,0x0e,0x0e,0x0f,0x0f,0x10,0x00,0x11,0x11,0x0e,0x0e,0x0f,0x0f,0x00,0x10,0x11,0x11,0x0f,0x0f,0x10,0x00,0x11,0x11,0x12,0x12,0x0f,0x0f,0x00,0x10,0x11,0x11,0x12,0x12,0x10,0x00,0x11,0x11,0x12,0x12,0x13,0x13,0x00,0x10,0x11,0x11,0x12,0x12,0x13,0x00,0x11,0x11,0x12,0x12,0x13,0x13,0x00,0x14,0x11,0x11,0x12,0x12,0x13,0x00,0x14,0x14,0x11,0x11,0x12,0x12,0x00,0x13,0x14,0x14,0x11,0x11,0x12,0x00,0x13,0x13,0x14,0x14,0x12,0x12,0x00,0x13,0x14,0x14,0x15,0x15,0x12,0x00,0x13,0x13,0x14,0x14,0x15,0x15,0x00,0x13,0x14,0x14,0x15,0x15,0x16,0x00,0x13,0x13,0x14,0x14,0x15,0x15,0x00,0x16,0x14,0x14,0x15,0x15,0x16,0x00,0x17,0x17,0x14,0x14,0x15,0x15,0x00,0x16,0x17,0x17,0x14,0x14,0x15,0x00,0x16,0x16,0x17,0x17,0x14,0x14,0x00,0x15,0x16,0x16,0x17,0x17,0x15,0x00,0x16,0x16,0x17,0x17,0x18,0x18,0x00,0x15,0x16,0x16,0x17,0x17,0x18,0x00,0x16,0x16,0x17,0x17,0x18,0x18,0x00,0x19,0x16,0x16,0x17,0x17,0x18,0x00,0x19,0x19,0x17,0x17,0x18,0x18,0x00,0x19,0x1a,0x1a,0x17,0x17,0x18,0x00,0x19,0x19,0x1a,0x1a,0x17,0x17,0x00,0x18,0x19,0x19,0x1a,0x1a,0x17,0x00,0x18,0x18,0x19,0x19,0x1a,0x1a,0x00,0x18,0x19,0x19,0x1a,0x1a,0x1b,0x00,0x18,0x18,0x19,0x19,0x1a,0x1a,0x00,0x1b,0x19,0x19,0x1a,0x1a,0x1b,0x00,0x1c,0x1c,0x19,0x19,0x1a,0x1a,0x00,0x1b,0x1c,0x1c,0x1a,0x1a,0x1b,0x00,0x1c,0x1c,0x1d,0x1d,0x1a,0x1a,0x00,0x1b,0x1c,0x1c,0x1d,0x1d,0x1a,0x00,0x1b,0x1b,0x1c,0x1c,0x1d,0x1d,0x00,0x1a,0x1b,0x1b,0x1c,0x1c,0x1d,0x00,0x1b,0x1b,0x1c,0x1c,0x1d,0x1d,0x00,0x1e,0x1b,0x1b,0x1c,0x1c,0x1d,0x00,0x1e,0x1e,0x1c,0x1c,0x1d,0x1d,0x00,0x1e,0x1f,0x1f,0x1c,0x1c,0x1d,0x00,0x1e,0x1e,0x1f,0x1f,0x1d,0x1d,0x00,0x1e,0x1f,0x1f,0x02,0x02,0x1d,0x00,0x1e,0x1e,0x1f,0x1f,0x02,0x02,0x00,0x1d,0x1e,0x1e,0x1f,0x1f,0x02,0x00,0x1d,0x1d,0x1e,0x1e,0x1f,0x1f,0x00,0x02,0x1e,0x1e,0x1f,0x1f,0x02,0x00,0x03,0x03,0x1e,0x1e,0x1f,0x1f,0x00,0x02,0x03,0x03,0x1f,0x1f,0x02,0x00,0x03,0x03,0x04,0x04,0x1f,0x1f,0x00,0x02,0x03,0x03,0x04,0x04,0x02,0x00,0x03,0x03,0x04,0x04,0x05,0x05,0x00,0x02,0x03,0x03,0x04,0x04,0x05,0x00,0x02,0x02,0x03,0x03,0x04,0x04,0x00,0x05,0x02,0x02,0x03,0x03,0x04,0x00,0x05,0x05,0x03,0x03,0x04,0x04,0x00,0x05,0x06,0x06,0x03,0x03,0x04,0x00,0x05,0x05,0x06,0x06,0x04,0x04,0x00,0x05,0x06,0x06,0x07,0x07,0x04,0x00,0x05,0x05,0x06,0x06,0x07,0x07,0x00,0x05,0x06,0x06,0x07,0x07,0x08,0x00,0x05,0x05,0x06,0x06,0x07,0x07,0x00,0x08,0x05,0x05,0x06,0x06,0x07,0x00,0x08,0x08,0x05,0x05,0x06,0x06,0x00,0x07,0x08,0x08,0x06,0x06,0x07,0x00,0x08,0x08,0x09,0x09,0x06,0x06,0x00,0x07,0x08,0x08,0x09,0x09,0x07,0x00,0x08,0x08,0x09,0x09,0x0a,0x0a,0x00,0x07,0x08,0x08,0x09,0x09,0x0a,0x00,0x08,0x08,0x09,0x09,0x0a,0x0a,0x00,0x0b,0x08,0x08,0x09,0x09,0x0a,0x00,0x0b,0x0b,0x08,0x08,0x09,0x09,0x00,0x0a,0x0b,0x0b,0x08,0x08,0x09,0x00,0x0a,0x0a,0x0b,0x0b,0x09,0x09,0x00,0x0a,0x0b,0x0b,0x0c,0x0c,0x09,0x00,0x0a,0x0a,0x0b,0x0b,0x0c,0x0c,0x00,0x0a,0x0b,0x0b,0x0c,0x0c,0x0d,0x00,0x0a,0x0a,0x0b,0x0b,0x0c,0x0c,0x00,0x0d,0x0b,0x0b,0x0c,0x0c,0x0d,0x00,0x0e,0x0e,0x0b,0x0b,0x0c,0x0c,0x00,0x0d,0x0e,0x0e,0x0b,0x0b,0x0c,0x00,0x0d,0x0d,0x0e,0x0e,0x0b,0x0b,0x00,0x0c,0x0d,0x0d,0x0e,0x0e,0x0c,0x00,0x0d,0x0d,0x0e,0x0e,0x0f,0x0f,0x00,0x0c,0x0d,0x0d,0x0e,0x0e,0x0f,0x00,0x0d,0x0d,0x0e,0x0e,0x0f,0x0f,0x00,0x10,0x0d,0x0d,0x0e,0x0e,0x0f,0x00,0x10,0x10,0x0e,0x0e,0x0f,0x0f,0x00,0x10,0x11,0x11,0x0e,0x0e,0x0f,0x00,0x10,0x10,0x11,0x11,0x0e,0x0e,0x00,0x0f,0x10,0x10,0x11,0x11,0x0e,0x00,0x0f,0x0f,0x10,0x10,0x11,0x11,0x00,0x0f,0x10,0x10,0x11,0x11,0x12,0x00,0x0f,0x0f,0x10,0x10,0x11,0x11,0x00,0x12,0x10,0x10,0x11,0x11,0x12,0x00,0x13,0x13,0x10,0x10,0x11,0x11,0x00,0x12,0x13,0x13,0x11,0x11,0x12,0x00,0x13,0x13,0x14,0x14,0x11,0x11,0x00,0x12,0x13,0x13,0x14,0x14,0x11,0x00,0x12,0x12,0x13,0x13,0x14,0x14,0x00,0x11,0x12,0x12,0x13,0x13,0x14,0x00,0x12,0x12,0x13,0x13,0x14,0x14,0x00,0x15,0x12,0x12,0x13,0x13,0x14,0x00,0x15,0x15,0x13,0x13,0x14,0x14,0x00,0x15,0x16,0x16,0x13,0x13,0x14,0x00,0x15,0x15,0x16,0x16,0x14,0x14,0x00,0x15,0x16,0x16,0x17,0x17,0x14,0x00,0x15,0x15,0x16,0x16,0x17,0x17,0x00,0x14,0x15,0x15,0x16,0x16,0x17,0x00,0x14,0x14,0x15,0x15,0x16,0x16,0x00,0x17,0x15,0x15,0x16,0x16,0x17,0x00,0x18,0x18,0x15,0x15,0x16,0x16,0x00,0x17,0x18,0x18,0x16,0x16,0x17,0x00,0x18,0x18,0x19,0x19,0x16,0x16,0x00,0x17,0x18,0x18,0x19,0x19,0x17,0x00,0x18,0x18,0x19,0x19,0x1a,0x1a,0x00,0x17,0x18,0x18,0x19,0x19,0x1a,0x00,0x17,0x17,0x18,0x18,0x19,0x19,0x00,0x1a,0x17,0x17,0x18,0x18,0x19,0x00,0x1a,0x1a,0x18,0x18,0x19,0x19,0x00,0x1a,0x1b,0x1b,0x18,0x18,0x19,0x00,0x1a,0x1a,0x1b,0x1b,0x19,0x19,0x00,0x1a,0x1b,0x1b,0x1c,0x1c,0x19,0x00,0x1a,0x1a,0x1b,0x1b,0x1c,0x1c,0x00,0x1a,0x1b,0x1b,0x1c,0x1c,0x1d,0x00,0x1a,0x1a,0x1b,0x1b,0x1c,0x1c,0x00,0x1d,0x1a,0x1a,0x1b,0x1b,0x1c,0x00,0x1d,0x1d,0x1a,0x1a,0x1b,0x1b,0x00,0x1c,0x1d,0x1d,0x1b,0x1b,0x1c,0x00,0x1d,0x1d,0x1e,0x1e,0x1b,0x1b,0x00,0x1c,0x1d,0x1d,0x1e,0x1e,0x1c,0x00,0x1d,0x1d,0x1e,0x1e,0x1f,0x1f,0x00,0x1c,0x1d,0x1d,0x1e,0x1e,0x1f,0x00,0x1d,0x1d,0x1e,0x1e,0x1f,0x1f,0x00,0x02,0x1d,0x1d,0x1e,0x1e,0x1f,0x00,0x02,0x02,0x1d,0x1d,0x1e,0x1e,0x00,0x1f,0x02,0x02,0x1d,0x1d,0x1e,0x00,0x1f,0x1f,0x02,0x02,0x1e,0x1e,0x00,0x1f,0x02,0x02,0x03,0x03,0x1e,0x00,0x1f,0x1f,0x02,0x02,0x03,0x03,0x00,0x1f,0x02,0x02,0x03,0x03,0x04,0x00,0x1f,0x1f,0x02,0x02,0x03,0x03,0x00,0x04,0x02,0x02,0x03,0x03,0x04,0x00,0x05,0x05,0x02,0x02,0x03,0x03,0x00,0x04,0x05,0x05,0x02,0x02,0x03,0x00,0x04,0x04,0x05,0x05,0x02,0x02,0x00,0x03,0x04,0x04,0x05,0x05,0x03,0x00,0x04,0x04,0x05,0x05,0x06,0x06,0x00,0x03,0x04,0x04,0x05,0x05,0x06,0x00,0x04,0x04,0x05,0x05,0x06,0x06,0x00,0x07,0x04,0x04,0x05,0x05,0x06,0x00,0x07,0x07,0x05,0x05,0x06,0x06,0x00,0x07,0x08,0x08,0x05,0x05,0x06,0x00,0x07,0x07,0x08,0x08,0x05,0x05,0x00,0x06,0x07,0x07,0x08,0x08,0x05,0x00,0x06,0x06,0x07,0x07,0x08,0x08,0x00,0x06,0x07,0x07,0x08,0x08,0x09,0x00,0x06,0x06,0x07,0x07,0x08,0x08,0x00,0x09,0x07,0x07,0x08,0x08,0x09,0x00,0x0a,0x0a,0x07,0x07,0x08,0x08,0x00,0x09,0x0a,0x0a,0x08,0x08,0x09,0x00,0x0a,0x0a,0x0b,0x0b,0x08,0x08,0x00,0x09,0x0a,0x0a,0x0b,0x0b,0x08,0x00,0x09,0x09,0x0a,0x0a,0x0b,0x0b,0x00,0x08,0x09,0x09,0x0a,0x0a,0x0b,0x00,0x09,0x09,0x0a,0x0a,0x0b,0x0b,0x00,0x0c,0x09,0x09,0x0a,0x0a,0x0b,0x00,0x0c,0x0c,0x0a,0x0a,0x0b,0x0b,0x00,0x0c,0x0d,0x0d,0x0a,0x0a,0x0b,0x00,0x0c,0x0c,0x0d,0x0d,0x0b,0x0b,0x00,0x0c,0x0d,0x0d,0x0e,0x0e,0x0b,0x00,0x0c,0x0c,0x0d,0x0d,0x0e,0x0e,0x00,0x0b,0x0c,0x0c,0x0d,0x0d,0x0e,0x00,0x0b,0x0b,0x0c,0x0c,0x0d,0x0d,0x00,0x0e,0x0c,0x0c,0x0d,0x0d,0x0e,0x00,0x0f,0x0f,0x0c,0x0c,0x0d,0x0d,0x00,0x0e,0x0f,0x0f,0x0d,0x0d,0x0e,0x00,0x0f,0x0f,0x10,0x10,0x0d,0x0d,0x00,0x0e,0x0f,0x0f,0x10,0x10,0x0e,0x00,0x0f,0x0f,0x10,0x10,0x11,0x11,0x00,0x0e,0x0f,0x0f,0x10,0x10,0x11,0x00}
//go:section .rodata
var sheetIndexROM = [ 64 ]uint16{0x0000,0x0001,0x0002,0x0003,0x0004,0x0005,0x0006,0x0007,0x0008,0x0009,0x000a,0x000b,0x000c,0x000d,0x000e,0x000f,0x0010,0x0011,0x0012,0x0013,0x0014,0x0015,0x0016,0x0017,0x0018,0x0019,0x001a,0x001b,0x001c,0x001d,0x001e,0x001f,0x0020,0x0021,0x0022,0x0023,0x0024,0x0025,0x0026,0x0027,0x0028,0x0029,0x002a,0x002b,0x002c,0x002d,0x002e,0x002f,0x0030,0x0031,0x0032,0x0033,0x0034,0x0035,0x0036,0x0037,0x0038,0x0039,0x003a,0x003b,0x003c,0x003d,0x003e,0x003f}
//go:section .rodata
var mapROM = [ 1024 ]uint16{0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x0001,0x0004,0x0007,0x000a,0x000d,0x0010,0x0013,0x0016,0x0019,0x001c,0x001f,0x0003,0x0006,0x0009,0x000c,0x000f,0x0012,0x0015,0x0018,0x001b,0x001e,0x0002,0x0005,0x0008,0x000b,0x000e,0x0011,0x0014,0x0017,0x001a,0x001d,0x0001}
//go:section .rodata
var flagROM = [ 64 ]byte{0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00}
//go:section .rodata
var poseIndexROM = [ 0 ]rt.PoseRange{}
const PoseVariantBaseCount = 0
var poseVariantNamesROM = []string(nil)
//go:section .rodata
var posePartROM = [ 0 ]rt.PosePart{}
//go:section .rodata
var animationClipROM = [0]rt.AnimationClip{}
//go:section .rodata
var animationFrameROM = [0]uint16{}
//go:section .rodata
var paletteROM = [256]uint16{0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9,0x0000,0x4567,0x0ace,0x4c35,0x119c,0x56e3,0x184a,0x5db1,0x2318,0x647f,0x29c6,0x6f2d,0x3094,0x75fb,0x3b42,0x7ca9}

//go:section .ewram
var sheetRAM [4032]byte
//go:section .ewram
var sheetIndexRAM [64]uint16
//go:section .ewram
var mapRAM [1024]uint16
//go:section .ewram
var flagRAM [64]byte
//go:section .ewram
var cartData rt.AssetMemory
//go:section .ewram
var ctx rt.Context
//go:section .ewram
var game Game
//go:section .debug_mailbox
var debugMailbox rt.DebugMailbox

type Game struct {
	tick rt.Number
	checksum rt.Number
	px rt.Value
	py rt.Value
	vx rt.Value
	vy rt.Value
}

type Runnable interface { Init(*rt.Context); Update(*rt.Context); Draw(*rt.Context) }
var _ Runnable = (*Game)(nil)

func (g *Game) Init(c *rt.Context) {
	if !c.SetFont(&projectFontROM) { panic("invalid project font") }
	c.RegisterGlobal(&g.px)
	c.RegisterGlobal(&g.py)
	c.RegisterGlobal(&g.vx)
	c.RegisterGlobal(&g.vy)
	glu_rhs_1 := rt.Number(0)
	g.tick = glu_rhs_1
	glu_rhs_2 := rt.Number(0)
	g.checksum = glu_rhs_2
	var glu_tbl_3 rt.Value
	glu_tblFail_4 := false
	var glu_tblErr_5 rt.HeapError
	glu_tbl_3, glu_tblErr_5 = c.NewTableWithCaps(128, 1)
	if glu_tblErr_5 != rt.HeapOK { glu_tblFail_4 = true }
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(1),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(2),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(3),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(4),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(5),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(6),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(7),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(8),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(9),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(10),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(11),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(12),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(13),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(14),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(15),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(16),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(17),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(18),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(19),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(20),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(21),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(22),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(23),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(24),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(25),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(26),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(27),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(28),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(29),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(30),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(31),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(32),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(33),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(34),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(35),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(36),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(37),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(38),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(39),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(40),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(41),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(42),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(43),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(44),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(45),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(46),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(47),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(48),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(49),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(50),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(51),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(52),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(53),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(54),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(55),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(56),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(57),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(58),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(59),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(60),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(61),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(62),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(63),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(64),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(65),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(66),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(67),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(68),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(69),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(70),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(71),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(72),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(73),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(74),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(75),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(76),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(77),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(78),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(79),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(80),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(81),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(82),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(83),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(84),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(85),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(86),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(87),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(88),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(89),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(90),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(91),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(92),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(93),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(94),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(95),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(96),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(97),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(98),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(99),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(100),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(101),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(102),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(103),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(104),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(105),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(106),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(107),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(108),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(109),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(110),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(111),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(112),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(113),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(114),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(115),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(116),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(117),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(118),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(119),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(120),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(121),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(122),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(123),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(124),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(125),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(126),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(127),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if !glu_tblFail_4 {
		if c.TableSet(glu_tbl_3,rt.IntVal(128),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_4 = true }
	}
	if glu_tblFail_4 { glu_tbl_3 = rt.NilVal() }
	glu_rhs_6 := glu_tbl_3
	g.px = glu_rhs_6
	var glu_tbl_7 rt.Value
	glu_tblFail_8 := false
	var glu_tblErr_9 rt.HeapError
	glu_tbl_7, glu_tblErr_9 = c.NewTableWithCaps(128, 1)
	if glu_tblErr_9 != rt.HeapOK { glu_tblFail_8 = true }
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(1),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(2),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(3),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(4),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(5),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(6),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(7),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(8),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(9),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(10),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(11),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(12),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(13),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(14),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(15),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(16),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(17),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(18),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(19),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(20),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(21),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(22),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(23),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(24),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(25),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(26),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(27),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(28),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(29),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(30),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(31),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(32),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(33),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(34),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(35),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(36),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(37),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(38),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(39),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(40),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(41),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(42),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(43),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(44),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(45),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(46),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(47),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(48),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(49),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(50),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(51),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(52),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(53),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(54),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(55),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(56),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(57),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(58),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(59),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(60),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(61),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(62),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(63),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(64),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(65),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(66),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(67),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(68),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(69),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(70),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(71),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(72),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(73),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(74),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(75),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(76),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(77),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(78),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(79),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(80),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(81),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(82),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(83),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(84),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(85),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(86),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(87),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(88),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(89),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(90),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(91),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(92),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(93),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(94),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(95),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(96),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(97),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(98),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(99),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(100),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(101),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(102),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(103),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(104),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(105),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(106),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(107),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(108),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(109),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(110),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(111),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(112),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(113),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(114),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(115),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(116),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(117),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(118),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(119),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(120),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(121),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(122),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(123),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(124),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(125),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(126),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(127),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if !glu_tblFail_8 {
		if c.TableSet(glu_tbl_7,rt.IntVal(128),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_8 = true }
	}
	if glu_tblFail_8 { glu_tbl_7 = rt.NilVal() }
	glu_rhs_10 := glu_tbl_7
	g.py = glu_rhs_10
	var glu_tbl_11 rt.Value
	glu_tblFail_12 := false
	var glu_tblErr_13 rt.HeapError
	glu_tbl_11, glu_tblErr_13 = c.NewTableWithCaps(128, 1)
	if glu_tblErr_13 != rt.HeapOK { glu_tblFail_12 = true }
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(1),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(2),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(3),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(4),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(5),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(6),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(7),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(8),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(9),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(10),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(11),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(12),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(13),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(14),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(15),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(16),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(17),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(18),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(19),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(20),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(21),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(22),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(23),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(24),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(25),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(26),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(27),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(28),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(29),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(30),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(31),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(32),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(33),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(34),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(35),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(36),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(37),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(38),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(39),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(40),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(41),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(42),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(43),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(44),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(45),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(46),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(47),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(48),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(49),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(50),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(51),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(52),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(53),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(54),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(55),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(56),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(57),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(58),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(59),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(60),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(61),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(62),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(63),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(64),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(65),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(66),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(67),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(68),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(69),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(70),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(71),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(72),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(73),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(74),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(75),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(76),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(77),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(78),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(79),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(80),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(81),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(82),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(83),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(84),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(85),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(86),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(87),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(88),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(89),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(90),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(91),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(92),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(93),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(94),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(95),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(96),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(97),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(98),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(99),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(100),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(101),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(102),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(103),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(104),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(105),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(106),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(107),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(108),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(109),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(110),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(111),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(112),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(113),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(114),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(115),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(116),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(117),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(118),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(119),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(120),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(121),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(122),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(123),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(124),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(125),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(126),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(127),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if !glu_tblFail_12 {
		if c.TableSet(glu_tbl_11,rt.IntVal(128),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_12 = true }
	}
	if glu_tblFail_12 { glu_tbl_11 = rt.NilVal() }
	glu_rhs_14 := glu_tbl_11
	g.vx = glu_rhs_14
	var glu_tbl_15 rt.Value
	glu_tblFail_16 := false
	var glu_tblErr_17 rt.HeapError
	glu_tbl_15, glu_tblErr_17 = c.NewTableWithCaps(128, 1)
	if glu_tblErr_17 != rt.HeapOK { glu_tblFail_16 = true }
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(1),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(2),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(3),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(4),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(5),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(6),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(7),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(8),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(9),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(10),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(11),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(12),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(13),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(14),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(15),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(16),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(17),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(18),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(19),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(20),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(21),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(22),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(23),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(24),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(25),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(26),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(27),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(28),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(29),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(30),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(31),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(32),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(33),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(34),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(35),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(36),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(37),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(38),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(39),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(40),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(41),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(42),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(43),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(44),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(45),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(46),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(47),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(48),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(49),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(50),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(51),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(52),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(53),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(54),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(55),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(56),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(57),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(58),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(59),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(60),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(61),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(62),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(63),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(64),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(65),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(66),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(67),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(68),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(69),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(70),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(71),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(72),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(73),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(74),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(75),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(76),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(77),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(78),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(79),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(80),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(81),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(82),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(83),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(84),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(85),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(86),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(87),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(88),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(89),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(90),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(91),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(92),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(93),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(94),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(95),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(96),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(97),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(98),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(99),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(100),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(101),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(102),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(103),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(104),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(105),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(106),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(107),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(108),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(109),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(110),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(111),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(112),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(113),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(114),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(115),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(116),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(117),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(118),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(119),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(120),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(121),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(122),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(123),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(124),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(125),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(126),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(127),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if !glu_tblFail_16 {
		if c.TableSet(glu_tbl_15,rt.IntVal(128),rt.NumVal(rt.Number(0))) != rt.HeapOK { glu_tblFail_16 = true }
	}
	if glu_tblFail_16 { glu_tbl_15 = rt.NilVal() }
	glu_rhs_18 := glu_tbl_15
	g.vy = glu_rhs_18
	g.gluInit(c)
}

func (g *Game) Update(c *rt.Context) {
	g.gluUpdate(c)
}

func (g *Game) Draw(c *rt.Context) {
	g.gluDraw(c)
}


func (g *Game) gluInit(c *rt.Context) {
	var l_i_1 rt.Number
	_ = l_i_1
	for glu_intFor_19 := 1; glu_intFor_19 <= 128; glu_intFor_19++ {
		l_i_1 = rt.FromInt(glu_intFor_19)
		glu_num_20 := l_i_1
		glu_num_21 := rt.Number(65536)
		glu_rhs_22 := (glu_num_20 - glu_num_21)
		var l_j_2 rt.Number = glu_rhs_22
		_ = l_j_2
		glu_lhs_23 := g.px
		glu_lhs_24 := rt.NumVal(l_i_1)
		glu_num_25 := rt.Number(524288)
		glu_num_26 := l_j_2
		glu_num_27 := rt.Number(851968)
		glu_num_28 := gluNumberModLit((glu_num_26).Mul(glu_num_27), 14417920)
		glu_rhs_29 := (glu_num_25 + glu_num_28)
		_ = gluTableSet(c, glu_lhs_23, glu_lhs_24, rt.NumVal(glu_rhs_29),glu_lhs_23,glu_lhs_24)
		glu_lhs_30 := g.py
		glu_lhs_31 := rt.NumVal(l_i_1)
		glu_num_32 := rt.Number(524288)
		glu_num_33 := l_j_2
		glu_num_34 := rt.Number(1114112)
		glu_num_35 := gluNumberModLit((glu_num_33).Mul(glu_num_34), 8912896)
		glu_rhs_36 := (glu_num_32 + glu_num_35)
		_ = gluTableSet(c, glu_lhs_30, glu_lhs_31, rt.NumVal(glu_rhs_36),glu_lhs_30,glu_lhs_31)
		glu_lhs_37 := g.vx
		glu_lhs_38 := rt.NumVal(l_i_1)
		glu_num_39 := gluNumberModLit(l_j_2, 458752)
		glu_num_40 := rt.Number(196608)
		glu_num_41 := (glu_num_39 - glu_num_40)
		glu_num_42 := rt.Number(8192)
		glu_rhs_43 := (glu_num_41).Mul(glu_num_42)
		_ = gluTableSet(c, glu_lhs_37, glu_lhs_38, rt.NumVal(glu_rhs_43),glu_lhs_37,glu_lhs_38)
		glu_lhs_44 := g.vy
		glu_lhs_45 := rt.NumVal(l_i_1)
		glu_num_46 := gluNumberModLit(l_j_2, 327680)
		glu_num_47 := rt.Number(131072)
		glu_num_48 := (glu_num_46 - glu_num_47)
		glu_num_49 := rt.Number(8192)
		glu_rhs_50 := (glu_num_48).Mul(glu_num_49)
		_ = gluTableSet(c, glu_lhs_44, glu_lhs_45, rt.NumVal(glu_rhs_50),glu_lhs_44,glu_lhs_45)
	}
}

func (g *Game) __glu_call_gluInit(c *rt.Context, roots ...rt.Value) {
	n := gluPushRoots(c, roots...)
	if n < 0 { return }
	g.gluInit(c)
	gluPopRoots(c,n)
}

func (g *Game) gluUpdate(c *rt.Context) {
	glu_num_51 := g.tick
	glu_num_52 := rt.Number(65536)
	glu_rhs_53 := (glu_num_51 + glu_num_52)
	g.tick = glu_rhs_53
	glu_rhs_54 := gluNumberModLit(g.tick, 7864320)
	var l_frame_3 rt.Number = glu_rhs_54
	_ = l_frame_3
	glu_rhs_55 := rt.Number(0)
	g.checksum = glu_rhs_55
	var l_i_4 rt.Number
	_ = l_i_4
	for glu_intFor_56 := 1; glu_intFor_56 <= 128; glu_intFor_56++ {
		l_i_4 = rt.FromInt(glu_intFor_56)
		glu_op_57 := g.px
		glu_op_58 := rt.NumVal(l_i_4)
		glu_rhs_59 := c.TableGet(glu_op_57, glu_op_58)
		var l_x_5 rt.Value = glu_rhs_59
		_ = l_x_5
		glu_op_60 := g.py
		glu_op_61 := rt.NumVal(l_i_4)
		glu_rhs_62 := c.TableGet(glu_op_60, glu_op_61)
		var l_y_6 rt.Value = glu_rhs_62
		_ = l_y_6
		glu_op_63 := g.vx
		glu_op_64 := rt.NumVal(l_i_4)
		glu_rhs_65 := c.TableGet(glu_op_63, glu_op_64)
		var l_dx_7 rt.Value = glu_rhs_65
		_ = l_dx_7
		glu_op_66 := g.vy
		glu_op_67 := rt.NumVal(l_i_4)
		glu_op_68 := c.TableGet(glu_op_66, glu_op_67)
		glu_op_69 := rt.NumVal(rt.Number(4096))
		glu_rhs_70 := (glu_op_68).Add(glu_op_69)
		var l_dy_8 rt.Value = glu_rhs_70
		_ = l_dy_8
		glu_op_71 := l_x_5
		glu_op_72 := l_dx_7
		glu_rhs_73 := (glu_op_71).Add(glu_op_72)
		l_x_5 = glu_rhs_73
		glu_op_74 := l_y_6
		glu_op_75 := l_dy_8
		glu_rhs_76 := (glu_op_74).Add(glu_op_75)
		l_y_6 = glu_rhs_76
		glu_op_77 := l_x_5
		glu_op_78 := rt.NumVal(rt.Number(262144))
		if (gluCmp(c,glu_op_77,glu_op_78,"<")) {
			glu_rhs_79 := rt.Number(262144)
			l_x_5 = rt.NumVal(glu_rhs_79)
			glu_arg_80 := l_dx_7
			glu_rhs_81 := (glu_arg_80).Abs()
			l_dx_7 = glu_rhs_81
		} else {
			glu_op_82 := l_x_5
			glu_op_83 := rt.NumVal(rt.Number(15400960))
			if (gluCmp(c,glu_op_82,glu_op_83,">")) {
				glu_rhs_84 := rt.Number(15400960)
				l_x_5 = rt.NumVal(glu_rhs_84)
				glu_arg_85 := l_dx_7
				glu_rhs_86 := rt.NumVal(-((glu_arg_85).Abs()).NumberOr(0))
				l_dx_7 = glu_rhs_86
			}
		}
		glu_op_87 := l_y_6
		glu_op_88 := rt.NumVal(rt.Number(262144))
		if (gluCmp(c,glu_op_87,glu_op_88,"<")) {
			glu_rhs_89 := rt.Number(262144)
			l_y_6 = rt.NumVal(glu_rhs_89)
			glu_arg_90 := l_dy_8
			glu_rhs_91 := (glu_arg_90).Abs()
			l_dy_8 = glu_rhs_91
		} else {
			glu_op_92 := l_y_6
			glu_op_93 := rt.NumVal(rt.Number(10158080))
			if (gluCmp(c,glu_op_92,glu_op_93,">")) {
				glu_rhs_94 := rt.Number(10158080)
				l_y_6 = rt.NumVal(glu_rhs_94)
				glu_arg_95 := l_dy_8
				glu_rhs_96 := rt.NumVal(-((glu_arg_95).Abs()).NumberOr(0))
				l_dy_8 = glu_rhs_96
			}
		}
		glu_lhs_97 := g.px
		glu_lhs_98 := rt.NumVal(l_i_4)
		glu_rhs_99 := l_x_5
		_ = gluTableSet(c, glu_lhs_97, glu_lhs_98, glu_rhs_99,l_x_5,l_y_6,l_dx_7,l_dy_8,glu_lhs_97,glu_lhs_98,glu_rhs_99)
		glu_lhs_100 := g.py
		glu_lhs_101 := rt.NumVal(l_i_4)
		glu_rhs_102 := l_y_6
		_ = gluTableSet(c, glu_lhs_100, glu_lhs_101, glu_rhs_102,l_x_5,l_y_6,l_dx_7,l_dy_8,glu_lhs_100,glu_lhs_101,glu_rhs_102)
		glu_lhs_103 := g.vx
		glu_lhs_104 := rt.NumVal(l_i_4)
		glu_rhs_105 := l_dx_7
		_ = gluTableSet(c, glu_lhs_103, glu_lhs_104, glu_rhs_105,l_x_5,l_y_6,l_dx_7,l_dy_8,glu_lhs_103,glu_lhs_104,glu_rhs_105)
		glu_lhs_106 := g.vy
		glu_lhs_107 := rt.NumVal(l_i_4)
		glu_rhs_108 := l_dy_8
		_ = gluTableSet(c, glu_lhs_106, glu_lhs_107, glu_rhs_108,l_x_5,l_y_6,l_dx_7,l_dy_8,glu_lhs_106,glu_lhs_107,glu_rhs_108)
		glu_op_109 := rt.NumVal(g.checksum)
		glu_arg_110 := l_x_5
		glu_op_111 := (glu_arg_110).Flr()
		glu_op_112 := (glu_op_109).Add(glu_op_111)
		glu_arg_113 := l_y_6
		glu_op_114 := (glu_arg_113).Flr()
		glu_rhs_115 := gluValueModLit((glu_op_112).Add(glu_op_114), 1048641536)
		g.checksum = (glu_rhs_115).NumberOr(0)
	}
}

func (g *Game) __glu_call_gluUpdate(c *rt.Context, roots ...rt.Value) {
	n := gluPushRoots(c, roots...)
	if n < 0 { return }
	g.gluUpdate(c)
	gluPopRoots(c,n)
}

func (g *Game) gluDraw(c *rt.Context) {
	glu_rhs_116 := gluNumberModLit(g.tick, 7864320)
	var l_frame_9 rt.Number = glu_rhs_116
	_ = l_frame_9
	glu_arg_117 := rt.Number(65536)
	c.ClsV(rt.NumVal(glu_arg_117))
	glu_arg_118 := rt.Number(0)
	glu_arg_119 := rt.Number(0)
	c.Camera((glu_arg_118).Int(),(glu_arg_119).Int())
}

func (g *Game) __glu_call_gluDraw(c *rt.Context, roots ...rt.Value) {
	n := gluPushRoots(c, roots...)
	if n < 0 { return }
	g.gluDraw(c)
	gluPopRoots(c,n)
}


var cartImage = rt.AssetImage{
		SheetW: SheetW, SheetH: SheetH, SpriteCols: SpriteCols, SpriteRows: SpriteRows, SpriteN: SpriteN,
		MapW: MapW, MapH: MapH, MapLayers: MapLayers, MapPlaneMask: MapPlaneMask, MapStreaming: MapStreaming, SheetReadOnly: SheetReadOnly, Sheet: sheetROM[:], Map: mapROM[:], Flags: flagROM[:],
		PoseIndex: poseIndexROM[:], PoseParts: posePartROM[:],
		PoseVariantBaseCount: 0, PoseVariantNames: poseVariantNamesROM,
		AnimationClips: animationClipROM[:], AnimationFrames: animationFrameROM[:],
		SheetIndex: sheetIndexROM[:],
}
func main() {
	rt.DebugLog("Cartridge preview started")
	cartData.SheetW, cartData.SheetH = SheetW, SheetH
	cartData.SpriteCols, cartData.SpriteRows, cartData.SpriteN = SpriteCols, SpriteRows, SpriteN
	cartData.MapW, cartData.MapH, cartData.MapLayers, cartData.MapPlaneMask = MapW, MapH, MapLayers, MapPlaneMask
	cartData.MapStreaming, cartData.SheetReadOnly = MapStreaming, SheetReadOnly
	cartData.Sheet = sheetRAM[:]
	cartData.SheetIndex = sheetIndexRAM[:]
	cartData.Map, cartData.Flags = mapRAM[:], flagRAM[:]
	cartData.PoseIndex, cartData.PoseParts = poseIndexROM[:], posePartROM[:]
	cartData.PoseVariantBaseCount, cartData.PoseVariantNames = 0, poseVariantNamesROM
	cartData.AnimationClips, cartData.AnimationFrames = animationClipROM[:], animationFrameROM[:]
	if !ctx.Init(&cartImage, &cartData) { rt.DebugLog("Cartridge assets could not be initialized. Rebuild the project."); for {} }
	ctx.LoadPalette(&paletteROM)
	ctx.InitHardware()
	ctx.SetProfiling(true)
	game.Init(&ctx)
	// _init runs while Mode 0 is force-blanked; commit its
	// spritesheet mutations before the first visible frame.
	ctx.FinalizeInitHardware()
	for {
		// One iteration = exactly two display frames (about 30 Hz).
		// The LCD always scans at 59.73 Hz;
		// each rendered image is shown for two whole scans. PaceFrame30
		// burns whatever time update/draw left over in the first frame, so
		// the flip always lands in the second frame's VBlank - a fast
		// iteration can never flip one frame early and alternate cadence.
		ctx.BeginFramePace()
		ctx.PollInput()
		ctx.PollPauseMenu()
		paused := ctx.PauseActive()
		if !paused {
		ctx.BeginProfilePhase(rt.ProfileUpdate)
		game.Update(&ctx)
		ctx.EndProfilePhase(rt.ProfileUpdate)
		ctx.BeginProfilePhase(rt.ProfileDraw)
		ctx.BeginRenderFrame()
		game.Draw(&ctx)
		ctx.EndProfilePhase(rt.ProfileDraw)
		// Finish renderer work off screen: Mode 4 already drew on the hidden
		// page, so nothing tears, and update+draw own the full two-frame
		// window (~562k cycles) minus only the flip itself.
		ctx.PrepareRender()
		ctx.CollectIfNeeded()
		}
		if paused { ctx.PreparePauseMenu() }
		ctx.PaceFrame30()
		ctx.WaitForPresentWindow()
		if paused { ctx.PresentPauseMenu() } else { ctx.PresentRender() }
		debugMailbox.Begin(ctx.DebugSnapshot())
		debugMailbox.Add("tick", rt.NumVal(game.tick))
		debugMailbox.Add("checksum", rt.NumVal(game.checksum))
		debugMailbox.Add("px", game.px)
		debugMailbox.Add("py", game.py)
		debugMailbox.Add("vx", game.vx)
		debugMailbox.Add("vy", game.vy)
		debugMailbox.End()
		ctx.EndFramePace30()
		ctx.WaitVDraw()
	}
}
