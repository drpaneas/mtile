tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
for i=0,63 do
local x=(i*13+frame)%220
local y=(i*17)%140
rectfill(x,y,x+9,y+9,2+i%30)
end
end
