tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
pal(2,2+(0+frame)%30,1)
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
map(0,flr((0)/8),0,0,0,31,21)
camera(0,0)
end
