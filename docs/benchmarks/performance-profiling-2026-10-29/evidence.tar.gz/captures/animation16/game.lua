tick=0
checksum=0
sprite_frame=1
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
local phase=flr(frame/4)%4
if phase==0 then sprite_frame=1 elseif phase==1 then sprite_frame=2 elseif phase==2 then sprite_frame=3 else sprite_frame=4 end
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
spr(sprite_frame,4+(frame%8),8,1,1)
spr(sprite_frame,22+(frame%8),8,1,1)
spr(sprite_frame,40+(frame%8),8,1,1)
spr(sprite_frame,58+(frame%8),8,1,1)
spr(sprite_frame,76+(frame%8),8,1,1)
spr(sprite_frame,94+(frame%8),8,1,1)
spr(sprite_frame,112+(frame%8),8,1,1)
spr(sprite_frame,130+(frame%8),8,1,1)
spr(sprite_frame,148+(frame%8),8,1,1)
spr(sprite_frame,166+(frame%8),8,1,1)
spr(sprite_frame,184+(frame%8),8,1,1)
spr(sprite_frame,202+(frame%8),8,1,1)
spr(sprite_frame,4+(frame%8),26,1,1)
spr(sprite_frame,22+(frame%8),26,1,1)
spr(sprite_frame,40+(frame%8),26,1,1)
spr(sprite_frame,58+(frame%8),26,1,1)
end
