tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
sset(8,0,2+(frame%2)*3)
sset(9,0,2+(frame%2)*3)
sset(10,0,2+(frame%2)*3)
sset(11,0,2+(frame%2)*3)
sset(12,0,2+(frame%2)*3)
sset(13,0,2+(frame%2)*3)
sset(14,0,2+(frame%2)*3)
sset(15,0,2+(frame%2)*3)
sset(8,1,2+(frame%2)*3)
sset(9,1,2+(frame%2)*3)
sset(10,1,2+(frame%2)*3)
sset(11,1,2+(frame%2)*3)
sset(12,1,2+(frame%2)*3)
sset(13,1,2+(frame%2)*3)
sset(14,1,2+(frame%2)*3)
sset(15,1,2+(frame%2)*3)
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
map(0,flr((0)/8),0,0,0,31,21)
camera(0,0)
end
