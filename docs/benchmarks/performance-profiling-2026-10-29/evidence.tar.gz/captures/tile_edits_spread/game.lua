tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
sset(8,0,2+(frame%2)*3)
sset(16,0,2+(frame%2)*3)
sset(24,0,2+(frame%2)*3)
sset(32,0,2+(frame%2)*3)
sset(40,0,2+(frame%2)*3)
sset(48,0,2+(frame%2)*3)
sset(56,0,2+(frame%2)*3)
sset(0,8,2+(frame%2)*3)
sset(8,8,2+(frame%2)*3)
sset(16,8,2+(frame%2)*3)
sset(24,8,2+(frame%2)*3)
sset(32,8,2+(frame%2)*3)
sset(40,8,2+(frame%2)*3)
sset(48,8,2+(frame%2)*3)
sset(56,8,2+(frame%2)*3)
sset(0,16,2+(frame%2)*3)
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
map(0,flr((0)/8),0,0,0,31,21)
camera(0,0)
end
