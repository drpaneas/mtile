tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
spr(1,4+(frame%8),8,4,4)
spr(1,32+(frame%8),8,4,4)
spr(1,60+(frame%8),8,4,4)
spr(1,88+(frame%8),8,4,4)
spr(1,116+(frame%8),8,4,4)
spr(1,144+(frame%8),8,4,4)
spr(1,172+(frame%8),8,4,4)
spr(1,200+(frame%8),8,4,4)
end
