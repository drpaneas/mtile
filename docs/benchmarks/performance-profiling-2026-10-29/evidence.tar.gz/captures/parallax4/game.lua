tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
end
function _draw()
local frame=tick%120
cls(1)
camera(frame*1,0)
map(0,flr((frame*1)/8),0,0,0,31,21)
camera(frame*2,0)
map(1,flr((frame*2)/8),0,0,0,31,21)
camera(frame*3,0)
map(2,flr((frame*3)/8),0,0,0,31,21)
camera(frame*4,0)
map(3,flr((frame*4)/8),0,0,0,31,21)
camera(0,0)
end
