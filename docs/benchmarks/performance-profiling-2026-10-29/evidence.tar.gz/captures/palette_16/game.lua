tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
pal(2,2+(0+frame)%30,1)
pal(3,2+(1+frame)%30,1)
pal(4,2+(2+frame)%30,1)
pal(5,2+(3+frame)%30,1)
pal(6,2+(4+frame)%30,1)
pal(7,2+(5+frame)%30,1)
pal(8,2+(6+frame)%30,1)
pal(9,2+(7+frame)%30,1)
pal(10,2+(8+frame)%30,1)
pal(11,2+(9+frame)%30,1)
pal(12,2+(10+frame)%30,1)
pal(13,2+(11+frame)%30,1)
pal(14,2+(12+frame)%30,1)
pal(15,2+(13+frame)%30,1)
pal(16,2+(14+frame)%30,1)
pal(17,2+(15+frame)%30,1)
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
map(0,flr((0)/8),0,0,0,31,21)
camera(0,0)
end
