tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
print("ABCD0123",8,8,7)
end
