tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
spr(1,4+(frame%8),8,1,1)
spr(1,22+(frame%8),8,1,1)
spr(1,40+(frame%8),8,1,1)
spr(1,58+(frame%8),8,1,1)
spr(1,76+(frame%8),8,1,1)
spr(1,94+(frame%8),8,1,1)
spr(1,112+(frame%8),8,1,1)
spr(1,130+(frame%8),8,1,1)
spr(1,148+(frame%8),8,1,1)
spr(1,166+(frame%8),8,1,1)
spr(1,184+(frame%8),8,1,1)
spr(1,202+(frame%8),8,1,1)
spr(1,4+(frame%8),26,1,1)
spr(1,22+(frame%8),26,1,1)
spr(1,40+(frame%8),26,1,1)
spr(1,58+(frame%8),26,1,1)
end
