tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
for i=0,1023 do
checksum=(checksum+mget((i*7+frame)%32,(i*11+frame)%32))%16001
end
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
end
