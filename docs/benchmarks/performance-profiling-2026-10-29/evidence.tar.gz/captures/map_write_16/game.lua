tick=0
checksum=0
function _init()

end
function _update()
tick=tick+1
local frame=tick%120
checksum=0
mset(0,0,2+frame%2)
mset(1,0,2+frame%2)
mset(2,0,2+frame%2)
mset(3,0,2+frame%2)
mset(4,0,2+frame%2)
mset(5,0,2+frame%2)
mset(6,0,2+frame%2)
mset(7,0,2+frame%2)
mset(8,0,2+frame%2)
mset(9,0,2+frame%2)
mset(10,0,2+frame%2)
mset(11,0,2+frame%2)
mset(12,0,2+frame%2)
mset(13,0,2+frame%2)
mset(14,0,2+frame%2)
mset(15,0,2+frame%2)
end
function _draw()
local frame=tick%120
cls(1)
camera(0,0)
map(0,flr((0)/8),0,0,0,31,21)
camera(0,0)
end
